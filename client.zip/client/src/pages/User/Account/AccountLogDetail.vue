<template>
	<div class="detail-list">
		<div class="card-div dis-box">
			<div>
				<p>{{$t('lang.recharge')}}</p>
				<span>2018-05-15 18:26:05</span>
			</div>
			<div class="box-flex text-right">
				<p>¥12.00</p>
				<span class="color-red">{{$t('lang.uncertain')}}</span>
			</div>
		</div>
	</div>
</template>
