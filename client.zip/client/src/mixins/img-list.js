export default{
    methods: {
        addImgList(){
            console.log(this.modulesIndex)
        }
    }
}