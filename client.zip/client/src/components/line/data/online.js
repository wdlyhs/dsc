module.exports = {
    module: "line",
    setting: '1',
    data: {
        allValue:{
            height:10,
            bgColor:""
        },
    }
}