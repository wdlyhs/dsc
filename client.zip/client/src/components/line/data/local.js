import i18n from '@/locales'
export default {
    module: "line",
    componentName: "辅助线",
    suggest: "",
    setting: "0",
    data: {
        allValue:{
        }
    }
}
