module.exports = {
    module: "product",
    setting: '1',
    data: {
        allValue:{
            number: 10,
            scrollNumber:3,
            categorySOption:'',
            brandSelect:'',
            selectGoodsId:[]
        },
        isStyleSel: "0",        
        isSizeSel: "0",
        tagSelList: ["0","1"],
        isModuleSel: "0"
    }
}