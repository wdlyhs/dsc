module.exports = {
    module: "nav",
    setting: '1',
    data: {
        list: [],
        styleSelList:["0","1","2"],
        isNumberSel:"5",
        isStyleSel:"0",
        isIconSel: "0",
        isDescSel:"0"
    }
}