module.exports = {
    module: "announcement",
    setting: '1',
    data: {
        allValue: {
            number: 10,
            img:"",
            announContent: "",
            optionCascaderVal:""
        },
        isStyleSel: '0',
        isDateSel: "0"
    }
}