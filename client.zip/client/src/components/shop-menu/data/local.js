import i18n from '@/locales'
export default {
    module: "shop-menu",
    componentName: i18n.t('lang.shop_menu'),
    suggest: "",
    setting: "0",
    data: {
        allValue:{
        }
    }
}
