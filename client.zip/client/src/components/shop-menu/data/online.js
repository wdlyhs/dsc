module.exports = {
    module: "count-down",
    setting: '0',
    data: {
        list: [],
        allValue: {
        },       
        isStyleSel: "0",
    }
}