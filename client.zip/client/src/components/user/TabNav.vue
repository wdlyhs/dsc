<template>
	<div class="tab-title">
			<slot name="tabItem"></slot>
	</div>
</template>
<script>
export default{
	data(){
		return {}
	}
}
</script>