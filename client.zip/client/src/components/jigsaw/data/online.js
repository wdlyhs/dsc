module.exports = {
    module: "jigsaw",
    setting: '0',
    data: {
        list: [
        ],
        allValue: {
            showStyle1Size:"1:1",
            showStyle1Right:"2",
            showStyle2Size: "1:2"
        },
        styleSelList:[],
        isStyleSel: "0",
        isPositionSel: "0"
    }
}