module.exports = {
    module: "slide",
    setting: '1',
    data: {
        list: [],
        allValue:{
            number:1
        },
        isStyleSel: '1',
        isSizeSel: '0',
    }
}