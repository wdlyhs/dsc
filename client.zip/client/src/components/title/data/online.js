module.exports = {
    module: "title",
    setting: "1",
    data: {
        allValue: {
            title: "",
            fitTitle: "",
            dateTime: "",
            author: "",
            bgColor: ""
        },
        list: [{
            desc: "",
            url: "",
            urlCatetory: "",
            urlName: ""
        }],
        isDate: "0",
        isStyleSel: "0",
        isPositionSel: "0"
    }
}