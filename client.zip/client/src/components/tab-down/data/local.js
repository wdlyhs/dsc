import i18n from '@/locales'
export default {
    module: "tab-down",
    componentName: i18n.t('lang.tab_down'),
    suggest: "",
    setting: "0",
    data: {
        list:[]
    }
}
