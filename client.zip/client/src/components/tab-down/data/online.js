module.exports = {
    module: "tab-down",
    setting: '0',
    data: {
        list: [{
            "img": "",
            "url": "",
            "desc": "",
            "urlCatetory": "",
            "urlName": ""
        },]
    }
}