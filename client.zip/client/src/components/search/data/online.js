module.exports = {
    module: "search",
    setting: '1',
    data: {
        allValue: {
            searchValue: "",
            fontColor:"",
            bgColor: "",
            tenKey: "",
            img: "",
        },
        isSuspendSel: "0",
        isPositionSel: "0",
        isLogoSel: "1",
        isMessageSel: "0"
    }
}