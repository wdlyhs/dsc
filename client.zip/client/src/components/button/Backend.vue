<template>
    <div id='b-line'>
        
    </div>
</template>

<script>
export default {
    name: 'b-line'

}
</script>

<style scoped>

</style>