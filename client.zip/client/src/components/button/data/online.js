module.exports = {
    module: "button",
    setting: '0',
    data: {
        list: [],
    }
}