<template>
    <div class='editor-input'>
        第三方
    </div>
</template>

<script>
export default {
    name: 'editor-input',
    props: ["value"]
}
</script>

<style scoped>

</style>