import i18n from '@/locales'
export default {
    module: "coupon",
    componentName: i18n.t('lang.coupons'),
    suggest: "",
    setting: "0",
    data: {
        list: [],
    }
}
