module.exports = {
    module: "coupon",
    setting: '0',
    data: {
        list: [],
    }
}