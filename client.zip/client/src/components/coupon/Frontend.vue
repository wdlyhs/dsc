<template>
    <div id='line'>
        
    </div>
</template>

<script>
export default {
    name: 'line'

}
</script>

<style scoped>

</style>