<template>
    <div id='b-coupon'>
        
    </div>
</template>

<script>
export default {
    name: 'b-coupon'

}
</script>

<style scoped>

</style>