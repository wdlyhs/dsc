module.exports = {
    module: "count-down",
    setting: '0',
    data: {
        list: [],
        allValue: {
            titleImg: "",
            productImg: "",
            spikeDesc: "",
            endTime: "",
            number:10
        },       
        isStyleSel: "0",
    }
}