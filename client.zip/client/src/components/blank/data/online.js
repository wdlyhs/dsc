module.exports = {
    module: "blank",
    setting: '1',
    data: {
        allValue:{
            height:2
        }
    }
}