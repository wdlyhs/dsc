import i18n from '@/locales'
export default {
    module: "blank",
    componentName: i18n.t('lang.blank'),
    suggest: "",
    setting: "0",
    data: {
        allValue:{
        }
    }
}
