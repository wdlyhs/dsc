module.exports = {
    module: "store",
    setting: '1',
    data: {
        allValue: {
            number: 10
        }
    }
}