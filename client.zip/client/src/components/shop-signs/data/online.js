module.exports = {
    module: "shop-signs",
    setting: '0',
    data: {
        allValue: {
            logoImage:"",
            backgroundImage:""
        }
    }
}