import i18n from '@/locales'
export default {
    module: "shop-signs",
    componentName: i18n.t('lang.shop_signs'),
    suggest: "",
    setting: "0",
    data: {
        allValue:{
        }
    }
}
