import qs from 'qs'
import axios from 'axios'

function test(){

}

export default {
	test
}