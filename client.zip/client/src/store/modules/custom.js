import {
    apiCustom
} from '@/config'

const state = {

}

const mutations = {

}

const actions = {

}

export default {
    state,
    mutations,
    actions,
}