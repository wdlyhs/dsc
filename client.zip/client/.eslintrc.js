module.exports = {
  root: true,
  env: {
    node: true
  },
  'extends': [
    'plugin:vue/essential',
    'eslint:recommended'
  ],
  globals: {
    uni: true
  },
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
    'no-tabs': 0,
    'no-mixed-spaces-and-tabs': 0,
    'indent': ["off", "tab"],
    'no-trailing-spaces': 0,
    'no-unused-vars': 0,
    'no-undef': 2,
    'no-irregular-whitespace': 0,
    'vue/return-in-computed-property': 0
  },
  parserOptions: {
    parser: 'babel-eslint'
  }
}
